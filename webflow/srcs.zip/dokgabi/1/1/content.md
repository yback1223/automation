독갑이™ ?
Birth of DOKGABI™(독갑이™)
「Dokgabi독갑이」 is a pure Korean word of Dokkaebi. DOKGABI™ inspired by Dokkaebi who helps people by staying close to them unlike ghosts and named as a no-code AI chatbot builder which has various appearances, personalities, and voices, but also finds and creates what users want together and helps people by staying close to them.

‍

Origin of Dokkaebi

Dokkaebi's origin is known as a folktale of the Silla period, and it is known that it is a miscellaneous ghost in the shape of an animal or person that has been passed down in Korea, and comes from objects that people have used in their daily lives, such as old brooms and old furniture.

Dokkaebi (Korean Goblin) is a hornless, large, hairy and is wearing traditional trouser jeogori, and also known as a grateful person who brings wealth to people or a friendly personality who likes to play.

Dokkaebi has a divine power, but unlike ghosts, she helps by staying close to people and helping them. Dokkaebi also punishes and punishes a liar or a greedy person, but it does not hurt a good person. So, Koreans heard that if they don't listen to their parents in their childhood, goblins will catch children, and if they listen to their parents well, goblins will give them gold and silver treasures in front of their house.

Dokkaebi not only likes to eat, drink, dance, and play loudly, but also blesses poor but good people and acts as lovers of old bachelor or widow, bringing them wealth or setting up a good place to live a good life. They use their divine power to let go of their legs or prevent beams (洑). However, those who lie, those who are not loyal, and those who are greedy are punished. This can be said to be the image of Korean inner consciousness via Dokkaebi.

‍

In fact, in Korea, idioms related to Dokkaebi are commonly used.

1) When you can't understand the inside of something and you can't get your head around it, you can say, "I think I'm possessed by Dokkaebi." For example, "What was in the drawer just a while ago is gone. I felt like I was possessed by a goblin."

2) When it's not clear what you're doing and you can't figure out what you're doing, it's expressed as 'It's like a Dokkaebi joke'. For example, "It's like a goblin joke."

‍

Vision of DOKGABI™
DOKGABI™(독갑이™)는 누구나 쉽게 사용할 수 있는 노코드 AI 챗봇 빌더로, 기술적인 지식이 없어도 손쉽게 챗봇을 제작할 수 있도록 돕습니다. 우리의 목표는 독갑이를 통해 모든 사용자가 창의적이고 유용한 챗봇을 만들 수 있도록 지원하는 것입니다. DOKGABI™(독갑이™)는 도깨비처럼 사용자들에게 신비한 도움을 주며, 복잡한 문제를 쉽게 해결할 수 있는 도구가 될 것입니다.

‍

이렇게, DOKGABI™(독갑이™)는 탄생하게 되었습니다. DOKGABI™(독갑이™)는 사용자들에게 혁신적인 솔루션을 제공하는 신비한 도구로 자리매김할 것입니다. DOKGABI™(독갑이™)를 통해 자신만의 특별한 챗봇을 만들어 보세요!